"use client";

import { motion } from "framer-motion";
import { ChevronRight, Percent, ShieldCheck, Sparkles } from "lucide-react";
import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { CategoryChips, PropertyCard, StoryBar, StoryViewer } from "@/components/property";
import { PropertyCardSkeleton } from "@/components/ui";
import { CATEGORIES } from "@/lib/constants";
import type { Property, Story } from "@/types";

type RecommendedProperty = Property & { matchScore: number };

export default function HomePage() {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [activeStory, setActiveStory] = useState<Story | null>(null);
  const [properties, setProperties] = useState<Property[]>([]);
  const [stories, setStories] = useState<Story[]>([]);
  const [recommended, setRecommended] = useState<RecommendedProperty[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch("/api/properties?limit=60").then((r) => r.json()),
      fetch("/api/stories").then((r) => r.json()),
    ])
      .then(([propsData, storiesData]) => {
        setProperties(propsData.properties ?? []);
        setStories(storiesData.stories ?? []);
      })
      .finally(() => setLoading(false));

    // AI Recommendation Engine — personalised picks based on the viewer's favorites.
    fetch("/api/ai/recommendations")
      .then((r) => r.json())
      .then((data) => setRecommended(data.recommendations ?? []))
      .catch(() => {});
  }, []);

  const filtered = useMemo(
    () => (activeCategory ? properties.filter((p) => p.category === activeCategory) : properties),
    [activeCategory, properties]
  );

  const featured = filtered.filter((p) => p.isVip).slice(0, 6);
  const latest = filtered.slice(0, 12);

  return (
    <div className="space-y-6 pb-4 pt-4">
      <div className="px-4">
        <Link
          href="/search"
          className="flex w-full items-center gap-3 rounded-[var(--radius-lg)] border border-border bg-white px-4 py-3.5 text-left shadow-[var(--shadow-soft)] active:scale-[0.99] transition-transform"
        >
          <Sparkles className="h-4.5 w-4.5 text-brand-400" />
          <span className="text-[14px] text-ink-700/50">Uy, kvartira, villa qidiring...</span>
        </Link>
      </div>

      <StoryBar stories={stories} onOpen={setActiveStory} />
      <StoryViewer story={activeStory} onClose={() => setActiveStory(null)} />

      <div className="px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="relative overflow-hidden rounded-[var(--radius-xl)] bg-gradient-to-br from-[#08233a] via-[#0b5c94] to-brand-500 p-5 text-white shadow-[var(--shadow-lift)]"
        >
          <motion.div
            className="absolute -right-6 -top-6 h-32 w-32 rounded-full bg-white/10"
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ repeat: Infinity, duration: 5 }}
          />
          <div className="relative flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-brand-100">
            <ShieldCheck className="h-3.5 w-3.5" /> Ishonchli platforma
          </div>
          <h2 className="text-display relative mt-2 max-w-[220px] text-[21px] leading-tight text-white">
            VIP e&apos;lon joylang — 3x ko&apos;proq mijoz toping
          </h2>
          <Link
            href="/profile"
            className="relative mt-4 flex w-fit items-center gap-1 rounded-full bg-white px-4 py-2 text-[13px] font-bold text-brand-600"
          >
            Batafsil <ChevronRight className="h-3.5 w-3.5" />
          </Link>
        </motion.div>
      </div>

      <div>
        <SectionTitle title="Toifalar" />
        <CategoryChips categories={CATEGORIES} active={activeCategory} onSelect={setActiveCategory} />
      </div>

      {(loading || featured.length > 0) && (
        <div>
          <SectionTitle title="Tavsiya etilgan" badge="VIP" />
          <div className="no-scrollbar flex gap-3.5 overflow-x-auto px-4 pb-1">
            {loading
              ? Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="w-[220px] shrink-0">
                    <PropertyCardSkeleton />
                  </div>
                ))
              : featured.map((p, i) => (
                  <div key={p.id} className="w-[220px] shrink-0">
                    <PropertyCard property={p} index={i} />
                  </div>
                ))}
          </div>
        </div>
      )}

      {recommended.length > 0 && (
        <div>
          <SectionTitle title="Siz uchun tavsiya" badge={<Sparkles className="h-3.5 w-3.5" />} />
          <div className="no-scrollbar flex gap-3.5 overflow-x-auto px-4 pb-1">
            {recommended.map((p, i) => (
              <div key={p.id} className="w-[220px] shrink-0">
                <PropertyCard property={p} index={i} matchScore={p.matchScore} />
              </div>
            ))}
          </div>
        </div>
      )}

      <div>
        <SectionTitle title="Yangi e'lonlar" badge={<Percent className="h-3.5 w-3.5" />} />
        <div className="grid grid-cols-2 gap-3.5 px-4">
          {loading
            ? Array.from({ length: 6 }).map((_, i) => <PropertyCardSkeleton key={i} />)
            : latest.map((p, i) => <PropertyCard key={p.id} property={p} index={i} />)}
        </div>
      </div>
    </div>
  );
}

function SectionTitle({ title, badge }: { title: string; badge?: React.ReactNode }) {
  return (
    <div className="mb-3 flex items-center justify-between px-4">
      <h2 className="text-heading text-[18px] text-ink-900">{title}</h2>
      {badge && (
        <span className="flex items-center gap-1 rounded-full bg-vip-bg px-2.5 py-1 text-[11px] font-bold text-vip-dark">
          {badge}
        </span>
      )}
    </div>
  );
}
